package OrderRegistration;

import java.util.ArrayList;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Order {
	private int orderID;
	private int numItems;
	private double totalPrice;
	private Item item;
	private String status;
	private String date;
	private String paymentMethod;
	private ArrayList<Item> orderItemList;
	
	public Order() {
		setDate();
		setOrderID(000);
		setNumItems(0);
		setItem(new Item());
		setOrderItemList(new ArrayList<Item>());
		
	}
	
	public Order(String status, String paymentMethod) {
		setOrderID(000);
		setNumItems(0);
		setStatus(status);
		setPaymentMethod(paymentMethod);
		setDate();
		orderItemList = new ArrayList<Item>();
	}
	
	public void createOrder(Order newOrder) {
		setStatus(newOrder.getStatus());
		setPaymentMethod(newOrder.getPaymentMethod());
		setOrderItemList(orderItemList);
		numItems = newOrder.getOrderItemList().size();
		setTotalPrice(calculateTotalPrice(newOrder.getOrderItemList(), numItems));
	}
	
	public double calculateTotalPrice(ArrayList<Item> orderItemList, int numItems) {
		// Sum the price of the items in the array
		
		for (int i = 0; i < numItems; i++) {
			totalPrice = totalPrice + orderItemList.get(i).getPrice();
		}
		
		return totalPrice;
	}
	
	public void addItem(Item item) {
		orderItemList.add(item);
	}

	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		orderID++;
		this.orderID = orderID;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDate() {
		return date;
	}

	public void setDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		date = dtf.format(now);
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public ArrayList<Item> getOrderItemList() {
		return orderItemList;
	}

	public void setOrderItemList(ArrayList<Item> orderItemList) {
		this.orderItemList = orderItemList;
	}

	@Override
	public String toString() {
		return "Date: " + getDate() + "\norderID: " + orderID +  
				"\nstatus: " + status + 
				"\npaymentMethod: " + paymentMethod + "\nItems: \n" + orderItemList +
				"\ntotalPrice: " + totalPrice;
	}

	public int getNumItems() {
		return numItems;
	}

	public void setNumItems(int numItems) {
		this.numItems = numItems;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}
	
	
}
