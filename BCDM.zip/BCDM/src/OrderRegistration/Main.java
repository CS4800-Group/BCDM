package OrderRegistration;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		createOrderDemo();
	}
	
	public static void createOrderDemo() {
		String welcomeMsg = "--- Create New Order ---";
		String statusMsg = "\nEnter status: ";
		String paymentMsg = "\nEnter payment method: ";
		String addItemMsg = "\n--- Add items ---";
		String itemMsg = "\nEnter item: ";
		String addMoreMsg = "\nAdd more items? (y/n)" + "\nEnter:";
		String priceMsg = "\nEnter price: ";
		String choice;
		Scanner input = new Scanner(System.in);
		
		// new Order object
		Order newOrder = new Order();
		
		System.out.println(welcomeMsg);
		
		// set order status to input
		System.out.println(statusMsg);
		newOrder.setStatus(input.nextLine());
		
		// set order payment method to input
		System.out.println(paymentMsg);
		newOrder.setPaymentMethod(input.nextLine());
		
		System.out.println(addItemMsg);
		
		// Loop to add multiple items
		do {
			// new Item object
			Item item = new Item();
			
			// set item name to input
			System.out.println(itemMsg);
			item.setName(input.next());
			
			// set item price to input
			System.out.println(priceMsg);
			item.setPrice(input.nextDouble());
			
			// add item to order
			newOrder.addItem(item);
			
			// asks to add more items
			System.out.println(addMoreMsg);
			choice = input.next();
			
		} while (!choice.contains("n"));
		
		
		newOrder.createOrder(newOrder);
		System.out.println(newOrder);
		
		input.close();
	}

}
