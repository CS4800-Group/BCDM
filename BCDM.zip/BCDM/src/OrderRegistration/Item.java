package OrderRegistration;

public class Item {
	private int itemID;
	private String name;
	private double price;
	
	public Item() {
		setItemID(0);
		setPrice(0.0);
	}
	
	public Item(String name, double price) {
		setItemID(0);
		setName(name);
		setPrice(price);
	}

	public int getItemID() {
		return itemID;
	}

	public void setItemID(int itemID) {
		this.itemID = itemID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "[itemID: " + itemID + ", dish: " + name + ", price: " + price + "]\n";
	}
	
	
}
