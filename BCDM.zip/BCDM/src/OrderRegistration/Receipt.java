package OrderRegistration;

import java.util.ArrayList;

public class Receipt {
	private ArrayList<Item> orderItemList;
	private int orderID;
	
	public Receipt() {
		
	}
	
	public Receipt(ArrayList<Item> orderItemList, int orderID) {
		setOrderItemList(orderItemList);
		setOrderID(orderID);
	}

	public ArrayList<Item> getOrderItemList() {
		return orderItemList;
	}

	public void setOrderItemList(ArrayList<Item> orderItemList) {
		this.orderItemList = orderItemList;
	}

	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
}
