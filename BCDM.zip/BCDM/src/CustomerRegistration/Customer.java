package CustomerRegistration;

public interface Customer {
	public void createCustomer();
}
