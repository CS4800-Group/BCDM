package CustomerRegistration;

public class Professor {
	private String professorID;
	private String name;
	private double discount;
	
	public Professor() {
		setDiscount(0.25);
	}
	
	public Professor(String professorID, String name) {
		setProfessorID(professorID);
		setName(name);
		setDiscount(0.25);
	}
	
	public String getProfessorID() {
		return professorID;
	}
	public void setProfessorID(String professorID) {
		this.professorID = professorID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
}
