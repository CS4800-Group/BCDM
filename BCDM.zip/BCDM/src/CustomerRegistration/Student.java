package CustomerRegistration;

public class Student implements Customer {
	private String studentID;
	private String name;
	private double discount;
	
	public Student() {
		setDiscount(0.50);
	}
	
	public Student(String studentID, String name) {
		setStudentID(studentID);
		setName(name);
		setDiscount(0.50);
	}
	
	@Override
	public void createCustomer() {
		
	}

	public String getStudentID() {
		return studentID;
	}

	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

}
